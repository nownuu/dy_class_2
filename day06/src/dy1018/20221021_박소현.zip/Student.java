package dy1018;

public class Student {
	
	String name;
	int stuId;
	int age;
	String phone;
	
	public Student() {}
	
}
