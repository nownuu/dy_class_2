package dy1018;

public class Dog {
	
	String name;
	String breed;
	int age;
	String color;
	
	public Dog() {}
	
	public void barking() {
		System.out.println("멍멍 짖는다.");
	}
	public void hungry() {
		System.out.println("배고파요");
	}
	public void sleeping() {
		System.out.println(" ZZzz..");
	}
}
