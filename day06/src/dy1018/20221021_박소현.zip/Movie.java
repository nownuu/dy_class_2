package dy1018;

public class Movie {
	
	String name;
	float score;
	String title;
	int date;
	
	public Movie() {}
	
	public void print() {
		System.out.println(name+score+title+date);
	}
}
